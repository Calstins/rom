function goback() {
  window.history.back();
}

function gocenter(){
  window.location.href = "./center.html";
}


function gouserinfo(){
  window.location.href = "./userinfo.html";
}

function gopassword(){
  window.location.href = "./password.html";
}
